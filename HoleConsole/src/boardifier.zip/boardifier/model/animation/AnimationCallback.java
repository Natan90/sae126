package boardifier.model.animation;

@FunctionalInterface
public interface AnimationCallback {
    public void execute();
}
